// src/App.jsx
import { useState } from "react";
import { getCurrentUser, logoutUser, updateUser } from "./utils/auth";
import { getClassById, addStudent, removeStudent } from "./utils/storage";

import Home from "./pages/Home.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import ProfDashboard from "./pages/ProfDashboard.jsx";
import EleveDashboard from "./pages/EleveDashboard.jsx";
import EleveClasse from "./pages/EleveClasse.jsx";
import ClassView from "./pages/ClassView.jsx";
import OutilsSport from "./pages/OutilsSport.jsx";

import OutilQuiFaitQuoiProf from "./pages/OutilQuiFaitQuoiProf.jsx";
import OutilQuiFaitQuoiEleve from "./pages/OutilQuiFaitQuoiEleve.jsx";

import "./styles/App.css";

export default function App() {
  const [user, setUser] = useState(getCurrentUser());
  const [page, setPage] = useState(user ? user.role : "home");
  const [selectedClass, setSelectedClass] = useState(null);
  const [selectedSport, setSelectedSport] = useState(null);
  const [selectedTool, setSelectedTool] = useState(null);

  function handleLogin(u) {
    setUser(u);

    if (u.role === "eleve" && u.classId) {
      const classe = getClassById(u.classId);
      if (classe) {
        setSelectedClass(classe);
        setPage("eleveclasse");
      } else {
        const updatedUser = { ...u, classId: null };
        updateUser(updatedUser);
        setUser(updatedUser);
        setPage("eleve");
      }
    } else {
      setPage(u.role);
    }
  }

  function handleLogout() {
    logoutUser();
    setUser(null);
    setPage("home");
    setSelectedClass(null);
    setSelectedSport(null);
    setSelectedTool(null);
  }

  // Professeur
  if (user && page === "prof") {
    return (
      <ProfDashboard
        user={user}
        onLogout={handleLogout}
        onSelectClass={(id) => {
          setSelectedClass(getClassById(id));
          setPage("classview");
        }}
        onSelectSport={(sport, classId) => {
          setSelectedSport(sport);
          setSelectedClass(getClassById(classId));
          setPage("outilssport");
        }}
      />
    );
  }

  // Vue d’une classe (professeur)
  if (user && page === "classview") {
    return (
      <ClassView
        classe={selectedClass}
        onBack={() => setPage("prof")}
        onSelectSport={(sport, classId) => {
          setSelectedSport(sport);
          setSelectedClass(getClassById(classId));
          setPage("outilssport");
        }}
      />
    );
  }

  // Élève déjà dans une classe
  if (user && page === "eleveclasse") {
    const classe = getClassById(user.classId);

    if (!classe) {
      const updatedUser = { ...user, classId: null };
      updateUser(updatedUser);
      setUser(updatedUser);
      return (
        <EleveDashboard
          user={updatedUser}
          onLogout={handleLogout}
          onJoinClass={(classe) => {
            const finalUser = { ...updatedUser, classId: classe.id };
            updateUser(finalUser);
            setUser(finalUser);
            addStudent(
              classe.id,
              finalUser.nom,
              finalUser.prenom,
              finalUser.email
            );
            setSelectedClass(classe);
            setPage("eleveclasse");
          }}
        />
      );
    }

    return (
      <EleveClasse
        user={user}
        classe={classe}
        onLogout={handleLogout}
        onSelectSport={(sport, classId) => {
          setSelectedSport(sport);
          setSelectedClass(getClassById(classId));
          setPage("outilssport");
        }}
      />
    );
  }

  // Élève pas encore dans une classe
  if (user && page === "eleve") {
    return (
      <EleveDashboard
        user={user}
        onLogout={handleLogout}
        onJoinClass={(classe) => {
          const updatedUser = { ...user, classId: classe.id };
          updateUser(updatedUser);
          setUser(updatedUser);
          addStudent(
            classe.id,
            updatedUser.nom,
            updatedUser.prenom,
            updatedUser.email
          );
          setSelectedClass(classe);
          setPage("eleveclasse");
        }}
      />
    );
  }

  // Page outils d’un sport
  if (user && page === "outilssport") {
    return (
      <OutilsSport
        sport={selectedSport}
        classe={selectedClass}
        onBack={() => {
          if (user.role === "prof") setPage("classview");
          else setPage("eleveclasse");
        }}
        onSelectTool={(tool) => {
          setSelectedTool(tool);
          setPage("toolroom");
        }}
      />
    );
  }

  // Page d’un outil
  if (user && page === "toolroom") {
    if (selectedTool.toolId === "outil-qfq-prof") {
      return (
        <OutilQuiFaitQuoiProf
          classe={selectedClass}
          onBack={() => setPage("outilssport")}
        />
      );
    }

    if (selectedTool.toolId === "outil-qfq-eleve") {
      let testUser = user;

      if (user.role === "prof") {
        const classe = getClassById(selectedClass.id);
        const hasTest = classe.eleves.find(
          (e) => e.email === "test-apercu@local"
        );
        if (!hasTest) {
          addStudent(classe.id, "Test", "(Aperçu)", "test-apercu@local");
        }

        testUser = {
          ...user,
          email: "test-apercu@local",
          prenom: "Test",
          nom: "(Aperçu)",
        };
      }

      return (
        <OutilQuiFaitQuoiEleve
          classe={selectedClass}
          user={testUser}
          onBack={() => setPage("outilssport")}
        />
      );
    }
  }

  // Inscription
  if (page === "register") {
    return (
      <Register
        onRegistered={(u) => handleLogin(u)}
        onBack={() => setPage("home")}
        onSwitch={() => setPage("login")}
      />
    );
  }

  // Connexion
  if (page === "login") {
    return (
      <Login
        onLogin={handleLogin}
        onBack={() => setPage("home")}
        onSwitch={() => setPage("register")}
      />
    );
  }

  // Page d’accueil
  return (
    <Home
      onGoLogin={() => setPage("login")}
      onGoRegister={() => setPage("register")}
    />
  );
}
